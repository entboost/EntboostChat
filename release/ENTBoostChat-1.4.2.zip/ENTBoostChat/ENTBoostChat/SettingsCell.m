//
//  SettingsCell.m
//  ENTBoostChat
//
//  Created by zhong zf on 14/11/28.
//  Copyright (c) 2014年 EB. All rights reserved.
//

#import "SettingsCell.h"
#import "CustomSeparator.h"

@implementation SettingsCell

@end

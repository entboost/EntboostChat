//
//  ServerConfigViewController.h
//  ENTBoostChat
//
//  Created by zhong zf on 14/10/31.
//  Copyright (c) 2014年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServerConfigViewController : UIViewController

@property(nonatomic, strong) IBOutlet UITextField* serverAddressTextField;
//@property(nonatomic, strong) IBOutlet UIButton* saveBtn;

@end

//
//  TalkSettingController.h
//  ENTBoostChat
//
//  Created by zhong zf on 15/12/18.
//  Copyright © 2015年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TalkSettingController : UITableViewController

@end

//
//  ChatSeparatorCell.m
//  ENTBoostChat
//
//  Created by zhong zf on 15/9/14.
//  Copyright (c) 2015年 EB. All rights reserved.
//

#import "ChatSeparatorCell.h"

@implementation ChatSeparatorCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

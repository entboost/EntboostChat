//
//  SearchPersonCell.m
//  ENTBoostChat
//
//  Created by zhong zf on 15/10/16.
//  Copyright © 2015年 EB. All rights reserved.
//

#import "SearchPersonCell.h"

@implementation SearchPersonCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

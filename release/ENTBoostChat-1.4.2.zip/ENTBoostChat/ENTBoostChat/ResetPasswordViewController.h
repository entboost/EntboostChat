//
//  ResetPasswordViewController.h
//  ENTBoostChat
//
//  Created by zhong zf on 15/8/29.
//  Copyright (c) 2015年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResetPasswordViewController : UIViewController <UIWebViewDelegate>

@property(nonatomic, strong) NSString* resetPwdUrl;

@end

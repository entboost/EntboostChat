//
//  SearchPersonCell.h
//  ENTBoostChat
//
//  Created by zhong zf on 15/10/16.
//  Copyright © 2015年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchPersonCell : UITableViewCell

@property(nonatomic, strong) IBOutlet UIImageView   *customImageView;
@property(nonatomic, strong) IBOutlet UILabel       *customTitleLabel;
@property(nonatomic, strong) IBOutlet UILabel       *customDetailLabel;
@property(nonatomic, strong) IBOutlet UILabel       *customDetailLabel2;

@end

//
//  ChangePasswordViewController.h
//  ENTBoostChat
//
//  Created by zhong zf on 15/11/14.
//  Copyright © 2015年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangePasswordViewController : UIViewController

@end

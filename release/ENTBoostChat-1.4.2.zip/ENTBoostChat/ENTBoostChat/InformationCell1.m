//
//  MyInformationCell.m
//  ENTBoostChat
//
//  Created by zhong zf on 14/11/29.
//  Copyright (c) 2014年 EB. All rights reserved.
//

#import "InformationCell1.h"

@implementation InformationCell1

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
}
@end

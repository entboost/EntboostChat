//
//  CoreTextLinkData.m
//  ENTBoostChat
//
//  Created by zhong zf on 14-11-15.
//  Copyright (c) 2014年 EB. All rights reserved.
//

#import "CoreTextLinkData.h"

@implementation CoreTextLinkData

@end

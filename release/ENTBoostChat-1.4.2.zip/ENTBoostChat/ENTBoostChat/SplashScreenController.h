//
//  SplashScreenController.h
//  ENTBoostChat
//
//  Created by zhong zf on 14-10-16.
//  Copyright (c) 2014年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashScreenController : UIViewController

@property(nonatomic, strong) IBOutlet UIImageView* imageView;

@end

//
//  SearchPersonController.h
//  ENTBoostChat
//
//  Created by zhong zf on 15/8/18.
//  Copyright (c) 2015年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchPersonController : UITableViewController

@end

//
//  ApplicationsViewController.h
//  ENTBoostChat
//
//  Created by zhong zf on 14-10-15.
//  Copyright (c) 2014年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>


@class MainViewController;

@interface ApplicationsViewController : UITableViewController

@property(weak, nonatomic) MainViewController* tabBarController; //tabBar控制器

@end

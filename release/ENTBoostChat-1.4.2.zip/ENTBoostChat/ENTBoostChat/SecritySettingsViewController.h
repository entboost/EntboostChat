//
//  SecritySettingsViewController.h
//  ENTBoostChat
//
//  Created by zhong zf on 15/11/16.
//  Copyright © 2015年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecritySettingsViewController : UITableViewController

@end

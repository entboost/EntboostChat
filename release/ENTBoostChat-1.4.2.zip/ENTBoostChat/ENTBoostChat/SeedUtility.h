//
//  seedUtility.h
//  ENTBoostChat
//
//  Created by zhong zf on 14-8-19.
//  Copyright (c) 2014年 EB. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SeedUtility : NSObject

//获取永不重复的UUID
+ (NSString*)uuid;

@end

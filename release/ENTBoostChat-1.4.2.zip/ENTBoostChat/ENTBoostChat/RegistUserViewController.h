//
//  RegistUserViewController.h
//  ENTBoostChat
//
//  Created by zhong zf on 15/8/28.
//  Copyright (c) 2015年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegistUserViewController : UIViewController

@end

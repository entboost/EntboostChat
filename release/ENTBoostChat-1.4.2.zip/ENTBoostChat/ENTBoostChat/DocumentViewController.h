//
//  DocumentViewController.h
//  ENTBoostChat
//
//  Created by zhong zf on 15/3/17.
//  Copyright (c) 2015年 EB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DocumentViewController : UIViewController

@property(nonatomic, strong) NSString* pathExtension; //文件扩展名
@property(nonatomic, strong) NSString* filePath; //文件路径

@end

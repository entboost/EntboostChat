//
//  EBSeedUtility.h
//  ENTBoostLib
//
//  Created by zhong zf on 14-9-1.
//  Copyright (c) 2014年 entboost. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EBSeedUtility : NSObject

//获取永不重复的UUID
+ (NSString*)uuid;

@end
